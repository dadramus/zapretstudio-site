﻿# Background worker for Zapret Studio. Runs in its own PowerShell runspace.
# Shared state is a synchronized hashtable; never write credentials to the log.
param($cli, $st)

$ErrorActionPreference = 'Stop'
function WLog([string]$message) {
    try { Add-Content -LiteralPath $st.LogPath -Value ((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff') + '  ' + $message) -Encoding UTF8 } catch { }
}
function Test-WarpTrace {
    # Connect directly, not through a configured system proxy, and avoid DNS.
    # A running process or a MASQUE handshake alone does not prove routing works.
    param([switch]$Quiet)
    $client = $null
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
        Add-Type -AssemblyName System.Net.Http
        $handler = New-Object System.Net.Http.HttpClientHandler
        $handler.UseProxy = $false
        $client = New-Object System.Net.Http.HttpClient($handler)
        $client.Timeout = [TimeSpan]::FromSeconds(8)
        $body = $client.GetStringAsync('https://1.1.1.1/cdn-cgi/trace').GetAwaiter().GetResult()
        # Пишем, что реально ответил Cloudflare: по полю ip видно, чей это выход,
        # по warp= — прошёл ли трафик через туннель. Без этого гадать бесполезно.
        $flat = (([string]$body) -replace "`r?`n", ' | ').Trim()
        if ($flat.Length -gt 400) { $flat = $flat.Substring(0, 400) }
        if (-not $Quiet) { WLog ('trace ответ: ' + $flat) }
        # адрес выхода — чтобы в панели было видно, что IP реально сменился
        $mIp = [regex]::Match([string]$body, '(?m)^ip=(\S+)\s*$')
        if ($mIp.Success) { $st.TraceIp = [string]$mIp.Groups[1].Value }
        $ok = ($body -match '(?m)^warp=(on|plus)\s*$')
        if (-not $ok -and -not $Quiet) { WLog 'trace: Cloudflare не подтвердил WARP (warp=off или поля нет)' }
        return $ok
    } catch {
        if (-not $Quiet) { WLog ('trace: запрос не прошёл — ' + $_.Exception.Message) }
        return $false
    }
    finally { if ($client) { $client.Dispose() } }
}
function Get-UsqueLinkState {
    if (-not $st.Proc) { return 'off' }
    try { if ($st.Proc.HasExited) { return 'off' } } catch { return 'off' }
    if (-not (Test-Path -LiteralPath $st.UsqueErr)) { return 'connecting' }
    # Читаем последние 64 КБ, а не «последние 300 строк»: usque любит сыпать
    # отладочными строками, и строка о подключении вымывается из окна за секунды.
    # После этого туннель рвался бы сам по себе на ровном месте.
    $text = ''
    try {
        $fs = [IO.File]::Open($st.UsqueErr, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
        try {
            $len = $fs.Length
            $take = [int][Math]::Min(65536, $len)
            if ($take -gt 0) {
                [void]$fs.Seek(-$take, [IO.SeekOrigin]::End)
                $buf = New-Object byte[] $take
                $read = $fs.Read($buf, 0, $take)
                $text = [Text.Encoding]::UTF8.GetString($buf, 0, $read)
            }
        } finally { $fs.Dispose() }
    } catch { return 'connecting' }
    $iConn = $text.LastIndexOf('Connected to MASQUE server')
    $iLost = -1
    foreach ($m in @('Tunnel connection lost', 'Failed to connect tunnel', 'Tunnel connection failed')) {
        $j = $text.LastIndexOf($m); if ($j -gt $iLost) { $iLost = $j }
    }
    if ($iConn -ge 0 -and $iConn -gt $iLost) { $st.LinkState = 'connected'; return 'connected' }
    if ($iLost -ge 0) { $st.LinkState = 'connecting'; return 'connecting' }
    # Ни одного маркера в окне: строка о подключении вымылась спамом usque.
    # Это не обрыв — держим прежнее состояние, иначе туннель рвётся сам по себе.
    if ([string]$st.LinkState -eq 'connected') { return 'connected' }
    return 'connecting'
}
function Close-Embedded {
    # Only the process started by this instance is ours. Never kill all usque processes.
    try { if ($st.Proc -and -not $st.Proc.HasExited) { $st.Proc.Kill(); [void]$st.Proc.WaitForExit(3000) } } catch { WLog ('остановка процесса: ' + $_.Exception.Message) }
    $st.TraceIp = ''; $st.LinkState = ''
    $st.CleanupError = ''
    try {
        if ($st.RouteState) { Remove-ZSWarpRoutes -State $st.RouteState; $st.RouteState = $null }
    } catch { $st.CleanupError = $_.Exception.Message; WLog ('очистка маршрутов: ' + $st.CleanupError) }
    foreach ($key in @('OutFile', 'ErrFile')) { try { if ($st[$key]) { $st[$key].Dispose() } } catch { }; $st[$key] = $null }
    try { if ($st.Proc) { $st.Proc.Dispose() } } catch { }
    $st.Proc = $null
}
function Invoke-Official([string[]]$arguments) {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $cli
    $psi.Arguments = (($arguments | ForEach-Object { if ($_ -match '\s') { '"' + $_ + '"' } else { $_ } }) -join ' ')
    $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
    $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
    $p = [Diagnostics.Process]::Start($psi)
    $out = $p.StandardOutput.ReadToEndAsync(); $err = $p.StandardError.ReadToEndAsync()
    if (-not $p.WaitForExit(15000)) { try { $p.Kill() } catch { }; throw 'Клиент Cloudflare не ответил за 15 секунд.' }
    $text = ([string]$out.Result + ' ' + [string]$err.Result).Trim()
    $code = $p.ExitCode; $p.Dispose()
    if ($code -ne 0) { throw ('Ошибка warp-cli (' + $code + '): ' + $text) }
    return $text
}
function Register-Embedded([string]$config) {
    if (Test-Path -LiteralPath $config) { return }
    $st.Stage = 'Регистрация устройства в Cloudflare…'
    $r = New-Object System.Diagnostics.ProcessStartInfo
    $r.FileName = [string]$st.Usque; $r.Arguments = '--config "' + $config + '" register -a'
    $r.WorkingDirectory = [string]$st.WarpDir
    $r.UseShellExecute = $false; $r.CreateNoWindow = $true
    $r.RedirectStandardOutput = $true; $r.RedirectStandardError = $true
    $p = [Diagnostics.Process]::Start($r)
    $out = $p.StandardOutput.ReadToEndAsync(); $err = $p.StandardError.ReadToEndAsync()
    $until = (Get-Date).AddSeconds(60)
    while (-not $p.WaitForExit(250)) {
        if ($st.Stop -or $st.Cancel -or (Get-Date) -ge $until) {
            try { $p.Kill() } catch { }
            if ($st.Stop -or $st.Cancel) { throw 'Подключение отменено.' }
            throw 'Регистрация не ответила за 60 секунд. Проверьте доступ к Cloudflare.'
        }
    }
    $code = $p.ExitCode; $p.Dispose()
    # Do not put registration output into logs: it may contain account details.
    if ($code -ne 0 -or -not (Test-Path -LiteralPath $config)) { throw 'Не удалось зарегистрировать устройство в Cloudflare. Проверьте доступ к сети и повторите попытку.' }
}
function Start-Embedded {
    $dir = [string]$st.WarpDir
    $cfg = Join-Path ([string]$st.DataDir) 'config.json'
    if (-not (Test-Path -LiteralPath (Join-Path $dir 'wintun.dll'))) { throw 'Не найден warp\wintun.dll.' }
    Register-Embedded $cfg
    if ($st.Cancel -or $st.Stop) { throw 'Подключение отменено.' }
    $st.Stage = 'Подготавливаю безопасный маршрут к Cloudflare…'
    # Второй туннель (VPN, sing-box) может держать маршрут конкретнее нашего default
    # и забирать проверочный адрес. Тогда trace честно покажет warp=off — и мы
    # хотя бы увидим в журнале, кто именно перехватил.
    try {
        $cover = @(Get-NetRoute -AddressFamily IPv4 -ErrorAction Stop | Where-Object {
            [string]$_.DestinationPrefix -ne '0.0.0.0/0' -and
            (Test-ZSWarpIPv4PrefixContains -Prefix ([string]$_.DestinationPrefix) -Address '1.1.1.1')
        })
        if ($cover.Count -gt 0) {
            WLog ('внимание: 1.1.1.1 перекрыт чужими маршрутами — ' + (($cover | ForEach-Object { [string]$_.DestinationPrefix + ' if' + [string]$_.InterfaceIndex }) -join ', '))
        }
    } catch { }
    $st.RouteState = Initialize-ZSWarpRoutes -ConfigPath $cfg -TunnelName 'ZapretWARP'
    if ($st.Cancel -or $st.Stop) { throw 'Подключение отменено.' }

    $st.UsqueOut = Join-Path $st.WorkDir 'usque-stdout.log'
    $st.UsqueErr = Join-Path $st.WorkDir 'usque-stderr.log'
    # A tiny file buffer makes short handshake messages visible while the process runs.
    $st.OutFile = New-Object System.IO.FileStream($st.UsqueOut, [IO.FileMode]::Create, [IO.FileAccess]::Write, [IO.FileShare]::ReadWrite, 1, $true)
    $st.ErrFile = New-Object System.IO.FileStream($st.UsqueErr, [IO.FileMode]::Create, [IO.FileAccess]::Write, [IO.FileShare]::ReadWrite, 1, $true)
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = [string]$st.Usque
    # The bundled client is MASQUE only; do not pass unsupported WireGuard/DoH settings.
    $psi.Arguments = '--config "' + $cfg + '" nativetun -n ZapretWARP --always-reconnect -k 15s'
    $psi.WorkingDirectory = $dir
    $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
    $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
    $st.Proc = [Diagnostics.Process]::Start($psi)
    $st.LinkState = ''
    $st.OutTask = $st.Proc.StandardOutput.BaseStream.CopyToAsync($st.OutFile)
    $st.ErrTask = $st.Proc.StandardError.BaseStream.CopyToAsync($st.ErrFile)
    WLog ('usque запущен, PID=' + $st.Proc.Id)
    $st.Stage = 'Ожидаю соединения с Cloudflare…'
    $until = (Get-Date).AddSeconds(50)
    while ((Get-Date) -lt $until -and -not $st.Stop -and -not $st.Cancel) {
        $link = Get-UsqueLinkState
        if ($link -eq 'off') { throw 'Встроенный клиент завершился. Подробности — в usque-stderr.log.' }
        if ($link -eq 'connected') { break }
        Start-Sleep -Milliseconds 400
    }
    if ($st.Stop -or $st.Cancel) { throw 'Подключение отменено.' }
    if ((Get-UsqueLinkState) -ne 'connected') { throw 'Cloudflare не ответил за 50 секунд. Проверьте сеть и usque-stderr.log.' }
    $st.Stage = 'Настраиваю маршруты туннеля…'
    Add-ZSWarpTunnelRoutes -State $st.RouteState
    if ($st.Stop -or $st.Cancel) { throw 'Подключение отменено.' }
    $st.Stage = 'Проверяю, что трафик проходит через WARP…'
    $verified = $false
    for ($i = 0; $i -lt 4 -and -not $st.Stop -and -not $st.Cancel; $i++) {
        if ((Get-UsqueLinkState) -eq 'connected' -and (Test-WarpTrace)) { $verified = $true; break }
        Start-Sleep -Milliseconds 800
    }
    if ($st.Stop -or $st.Cancel) { throw 'Подключение отменено.' }
    if (-not $verified) { throw 'Туннель создан, но Cloudflare не подтвердил прохождение трафика. Маршруты отменены; проверьте VPN, прокси и журнал.' }
    $st.Status = "Status update: Connected`nNetwork: healthy"
    $st.Stage = 'Подключено · трафик подтверждён Cloudflare'
    $st.Result = 'ok'; $st.LastVerified = Get-Date
    WLog 'WARP подтверждён запросом Cloudflare trace'
    # Удержание IP: первый раз запоминаем адрес, дальше сверяем каждый подъём.
    if ($st.HoldEnabled) {
        if (-not [string]$st.HoldIp) {
            $st.HoldIp = [string]$st.TraceIp
            if ($st.HoldIp) { WLog ('удержание IP: запоминаю ' + [string]$st.HoldIp) }
        } elseif ([string]$st.TraceIp -and [string]$st.TraceIp -ne [string]$st.HoldIp) {
            if ($st.HoldTries -lt 4) {
                $st.HoldTries++
                WLog ('удержание IP: пришёл ' + [string]$st.TraceIp + ', нужен ' + [string]$st.HoldIp + ' — переподключаюсь (' + [string]$st.HoldTries + ' из 4)')
                $st.WantReconnect = $true
            } else {
                WLog ('удержание IP: не вышло вернуть ' + [string]$st.HoldIp + ', остаюсь на ' + [string]$st.TraceIp)
                $st.HoldIp = [string]$st.TraceIp; $st.HoldTries = 0
            }
        } else { $st.HoldTries = 0 }
    }
}

try {
    if ($st.Embedded) {
        # Маршруты строятся на NetTCPIP/NetAdapter. В отдельном runspace модули
        # не всегда подгружаются сами — тянем явно, иначе Get-NetRoute молча пусто.
        try { Import-Module NetTCPIP, NetAdapter -ErrorAction Stop }
        catch { WLog ('сетевые модули: ' + $_.Exception.Message) }
        . (Join-Path $st.WarpDir 'WarpNetwork.ps1')
        # маршрутные шаги пишем в тот же журнал, что и воркер;
        # netsh-обход нужен, потому что New-NetRoute на Wintun отдаёт 1231
        $script:ZSTrace = { param($m) WLog $m }
        $script:ZSAllowNetshFallback = $true
    }
    WLog 'поток управления запущен'
    while (-not $st.Stop) {
        # Удержание IP: туннель снимается и поднимается заново, чтобы вернуть
        # прежний адрес выхода. Цель — чтобы игра не увидела смену IP.
        if ($st.WantReconnect -and -not $st.Busy) {
            $st.WantReconnect = $false
            $st.WantDisconnect = $true
            $st.WantConnect = $true
            $st.TraceIp = ''
            WLog 'удержание IP: переподключаю туннель'
        }
        if ($st.WantDisconnect -and -not $st.Busy) {
            $st.WantDisconnect = $false; $st.Busy = $true; $st.Stage = 'Отключаю…'
            try {
                if ($st.Embedded) { Close-Embedded }
                else { [void](Invoke-Official @('disconnect')); $st.OfficialManaged = $false }
                if ($st.CleanupError) { throw ('Не удалось полностью удалить маршруты: ' + $st.CleanupError) }
                $st.Status = 'Status update: Disconnected'; $st.Stage = 'Отключено'; $st.Result = 'off'; $st.Error = ''
                WLog 'туннель отключён'
            } catch { $st.Error = $_.Exception.Message; $st.Stage = 'Ошибка: ' + $st.Error; $st.Result = 'fail'; WLog $st.Stage }
            $st.Busy = $false
        }
        if ($st.WantConnect -and -not $st.Busy) {
            $st.WantConnect = $false; $st.Busy = $true; $st.Result = ''; $st.Error = ''; $st.Cancel = $false
            try {
                if ($st.Embedded) {
                    if ($st.Proc -or $st.RouteState) { Close-Embedded }
                    if ($st.CleanupError) { throw ('Сначала устраните ошибку удаления маршрутов: ' + $st.CleanupError) }
                    Start-Embedded
                } else {
                    $before = Invoke-Official @('status')
                    if ($before -notmatch 'Status update:\s*Connected') {
                        $st.Stage = 'Передаю команду клиенту Cloudflare…'
                        [void](Invoke-Official @('connect')); $st.OfficialManaged = $true
                    }
                    $until = (Get-Date).AddSeconds(35); $ok = $false
                    while ((Get-Date) -lt $until -and -not $st.Stop -and -not $st.Cancel) {
                        $s = Invoke-Official @('status'); $st.Status = $s
                        if ($s -match 'Status update:\s*Connected') { $ok = $true; break }
                        Start-Sleep -Milliseconds 700
                    }
                    if ($st.Stop -or $st.Cancel) { throw 'Подключение отменено.' }
                    if (-not $ok) { throw 'Клиент Cloudflare не подтвердил подключение.' }
                    $st.Stage = 'Подключено по данным клиента Cloudflare'; $st.Result = 'ok'
                }
            } catch {
                $cancelled = $st.Cancel -or $st.Stop
                $cause = $_.Exception.Message
                if ($_.Exception.Data['ZSWarpState'] -and -not $st.RouteState) { $st.RouteState = $_.Exception.Data['ZSWarpState'] }
                if ($st.Embedded) { Close-Embedded }
                elseif ($cancelled -and $st.OfficialManaged) { try { [void](Invoke-Official @('disconnect')) } catch { }; $st.OfficialManaged = $false }
                $st.Status = 'Status update: Disconnected'
                if ($st.CleanupError) { $cause += ' Не удалось полностью удалить маршруты: ' + $st.CleanupError }
                if ($cancelled -and -not $st.CleanupError) { $st.Stage = 'Отменено'; $st.Result = 'off'; $st.Error = '' }
                else { $st.Error = $cause; $st.Stage = 'Ошибка: ' + $st.Error; $st.Result = 'fail'; WLog $st.Stage }
            }
            $st.Cancel = $false; $st.Busy = $false
        }
        if (-not $st.Busy) {
            if ($st.Embedded -and $st.Proc) {
                $link = Get-UsqueLinkState
                if ($link -eq 'connected') { $st.LostAt = $null }
                if ($link -eq 'off') {
                    Close-Embedded; $st.Status = 'Status update: Disconnected'; $st.Result = 'fail'
                    $st.Error = 'Встроенный клиент завершился.'
                    if ($st.CleanupError) { $st.Error += ' Ошибка удаления маршрутов: ' + $st.CleanupError }
                    $st.Stage = 'Ошибка: ' + $st.Error; WLog $st.Error
                } elseif ($link -eq 'connecting') {
                    # Краткий обрыв не повод рвать всё: --always-reconnect обычно
                    # поднимает сессию сам, и адрес выхода при этом не меняется.
                    # Ждём 25 секунд, и только потом снимаем маршруты, чтобы не
                    # оставить «чёрную дыру» вместо интернета.
                    if (-not $st.LostAt) {
                        $st.LostAt = Get-Date
                        WLog 'туннель просел — даю 25 секунд на самовосстановление'
                    } elseif (((Get-Date) - $st.LostAt).TotalSeconds -ge 25) {
                        Close-Embedded; $st.LostAt = $null
                        $st.Status = 'Status update: Disconnected'; $st.Result = 'fail'
                        $st.Error = 'Соединение с Cloudflare прервалось. Включите WARP ещё раз.'
                        if ($st.CleanupError) { $st.Error += ' Ошибка удаления маршрутов: ' + $st.CleanupError }
                        $st.Stage = 'Ошибка: ' + $st.Error; WLog $st.Error
                    }
                }
                # Удержание IP: раз в минуту сверяем адрес выхода с запомненным.
                if ($st.HoldEnabled -and $st.HoldIp -and $link -eq 'connected') {
                    if (-not $st.LastIpCheck -or ((Get-Date) - $st.LastIpCheck).TotalSeconds -ge 60) {
                        $st.LastIpCheck = Get-Date
                        if (Test-WarpTrace -Quiet) {
                            if ([string]$st.TraceIp -ne [string]$st.HoldIp) {
                                if ($st.HoldTries -lt 4) {
                                    $st.HoldTries++
                                    WLog ('удержание IP: адрес сменился на ' + [string]$st.TraceIp + ', возвращаю ' + [string]$st.HoldIp + ' (попытка ' + [string]$st.HoldTries + ' из 4)')
                                    $st.WantReconnect = $true
                                } else {
                                    WLog ('удержание IP: не удалось вернуть ' + [string]$st.HoldIp + ', остаюсь на ' + [string]$st.TraceIp)
                                    $st.HoldIp = [string]$st.TraceIp; $st.HoldTries = 0
                                }
                            } else { $st.HoldTries = 0 }
                        }
                    }
                }
            } elseif (-not $st.Embedded) {
                try { $st.Status = Invoke-Official @('status') } catch { $st.Status = ''; $st.Error = $_.Exception.Message }
            }
        }
        Start-Sleep -Milliseconds 850
    }
} catch {
    $st.Error = $_.Exception.Message; $st.Stage = 'Ошибка: ' + $st.Error; $st.Result = 'fail'; $st.Busy = $false
    WLog ('ошибка фонового потока: ' + $st.Error)
} finally {
    if ($st.Embedded) { Close-Embedded }
    elseif ($st.OfficialManaged) { try { [void](Invoke-Official @('disconnect')) } catch { } }
    WLog 'поток управления остановлен'
}
