﻿# Windows PowerShell 5.1. Dot-source this file in the elevated caller's runspace.
#
# Scope: IPv4 MASQUE over endpoint_v4 only (not usque --ipv6 or --http2).
# No IPv6 routes are created or removed; native IPv6 may bypass the tunnel.
# Run Initialize BEFORE starting usque and BEFORE any hook installs defaults;
# start usque without up.bat/down.bat or other route-mutating hooks; once the
# ZapretWARP interface is ready call Add. Stop usque, then call Remove.
# This file is not an integration point and does not start or verify usque.
#
# The returned in-memory state contains only public routing metadata, never
# the JSON configuration or credentials. Keep the original object; do not
# edit or deserialize it. Calls must be serialized. Windows has no owner tag
# for NetRoute: an identical route replaced by another actor between our checks
# cannot be distinguished. Do not concurrently manage these exact route keys.
# Windows requires elevation; NetTCPIP and the built-in NetAdapter are used.

# Необязательная трассировка: воркер подставляет свой приёмник, тесты её не задают.
$script:ZSTrace = $null
$script:ZSAllowNetshFallback = $false
function Write-ZSTrace([string]$message) {
    if (-not $script:ZSTrace) { return }
    try { & $script:ZSTrace $message } catch { }
}

function Get-ZSWarpIPv4Routes {
    @(Get-NetRoute -AddressFamily IPv4 -PolicyStore ActiveStore -ErrorAction Stop)
}

function Test-ZSWarpIPv4PrefixContains {
    param([Parameter(Mandatory = $true)][string]$Prefix,
          [Parameter(Mandatory = $true)][string]$Address)
    $parts = $Prefix.Split('/')
    $net = $null; $ip = $null; $length = 0
    if ($parts.Count -ne 2 -or -not [int]::TryParse($parts[1], [ref]$length) -or
        $length -lt 0 -or $length -gt 32 -or
        -not [System.Net.IPAddress]::TryParse($parts[0], [ref]$net) -or
        -not [System.Net.IPAddress]::TryParse($Address, [ref]$ip) -or
        $net.AddressFamily -ne [System.Net.Sockets.AddressFamily]::InterNetwork -or
        $ip.AddressFamily -ne [System.Net.Sockets.AddressFamily]::InterNetwork) {
        throw 'Cannot safely interpret an IPv4 route prefix.'
    }
    $a = $net.GetAddressBytes(); $b = $ip.GetAddressBytes()
    for ($i = 0; $i -lt 4; $i++) {
        $bits = [Math]::Min(8, [Math]::Max(0, $length - 8 * $i))
        if ($bits -eq 0) { break }
        $mask = (255 -shl (8 - $bits)) -band 255
        if (($a[$i] -band $mask) -ne ($b[$i] -band $mask)) { return $false }
    }
    return $true
}

function Get-ZSWarpBestRoute {
    param([Parameter(Mandatory = $true)][string]$Address)
    $result = @(Find-NetRoute -RemoteIPAddress $Address -ErrorAction Stop | Where-Object {
        $null -ne $_.PSObject.Properties['DestinationPrefix'] -and
        $null -ne $_.PSObject.Properties['NextHop']
    })
    if ($result.Count -ne 1) { throw "Could not determine a unique best IPv4 route to $Address." }
    return $result[0]
}

# Find-NetRoute на on-link default через Wintun отдаёт 1231 «Сетевая папка недоступна».
# Считаем победителя сами: самый длинный префикс, затем меньшая эффективная метрика.
function Get-ZSWarpRouteByTable {
    param([Parameter(Mandatory = $true)][string]$Address)
    $cand = @(Get-ZSWarpIPv4Routes | Where-Object {
        try { Test-ZSWarpIPv4PrefixContains -Prefix ([string]$_.DestinationPrefix) -Address $Address } catch { $false }
    })
    if ($cand.Count -eq 0) { return $null }
    $ifs = @(Get-NetIPInterface -AddressFamily IPv4 -ErrorAction SilentlyContinue)
    $scored = foreach ($r in $cand) {
        $plen = 0
        $parts = ([string]$r.DestinationPrefix).Split('/')
        if ($parts.Count -eq 2) { [void][int]::TryParse($parts[1], [ref]$plen) }
        $im = 0
        $f = @($ifs | Where-Object { [uint32]$_.InterfaceIndex -eq [uint32]$r.InterfaceIndex })
        if ($f.Count -eq 1) { $im = [long]$f[0].InterfaceMetric }
        [pscustomobject]@{ Route = $r; Plen = $plen; Eff = ($im + [long]$r.RouteMetric) }
    }
    $best = @($scored | Sort-Object -Property @{ Expression = 'Plen'; Descending = $true }, @{ Expression = 'Eff'; Descending = $false })
    if ($best.Count -eq 0) { return $null }
    return $best[0].Route
}

function Get-ZSWarpPhysicalAdapter {
    param([Parameter(Mandatory = $true)][uint32]$InterfaceIndex,
          [Parameter(Mandatory = $true)][string]$TunnelName)
    $matches = @(Get-NetAdapter -Physical -ErrorAction Stop | Where-Object {
        [uint32]$_.InterfaceIndex -eq $InterfaceIndex -and
        [string]$_.Name -ne $TunnelName -and [string]$_.Status -eq 'Up'
    })
    if ($matches.Count -ne 1) {
        throw "Best endpoint route is not through a unique, up physical adapter distinct from $TunnelName (index $InterfaceIndex)."
    }
    return $matches[0]
}

function Add-ZSWarpOwnedRoute {
    param([Parameter(Mandatory = $true)]$State,
          [Parameter(Mandatory = $true)][string]$Kind,
          [Parameter(Mandatory = $true)][string]$DestinationPrefix,
          [Parameter(Mandatory = $true)][uint32]$InterfaceIndex,
          [Parameter(Mandatory = $true)][string]$NextHop,
          [Parameter(Mandatory = $true)][uint16]$Metric)
    $existing = @(Get-ZSWarpIPv4Routes | Where-Object {
        [string]$_.DestinationPrefix -eq $DestinationPrefix -and
        [uint32]$_.InterfaceIndex -eq $InterfaceIndex -and [string]$_.NextHop -eq $NextHop
    })
    if ($existing.Count -ne 0) {
        throw "Route conflict: $DestinationPrefix via $NextHop on interface $InterfaceIndex already exists; it is not ours."
    }
    $created = @(); $viaFallback = $false
    try {
        $created = @(New-NetRoute -AddressFamily IPv4 -DestinationPrefix $DestinationPrefix `
            -InterfaceIndex $InterfaceIndex -NextHop $NextHop -RouteMetric $Metric `
            -Protocol NetMgmt -PolicyStore ActiveStore -Confirm:$false -ErrorAction Stop)
    } catch {
        $netErr = $_.Exception.Message
        Write-ZSTrace ('New-NetRoute не сработал (' + $DestinationPrefix + '): ' + $netErr)
        $exists = @(Get-ZSWarpIPv4Routes | Where-Object {
            [string]$_.DestinationPrefix -eq $DestinationPrefix -and
            [uint32]$_.InterfaceIndex -eq $InterfaceIndex -and [string]$_.NextHop -eq $NextHop
        })
        if ($exists.Count -ne 0) {
            # Маршрут появился, хотя вызов упал: чей он — не доказано. Не присваиваем.
            $State.UncertainRoute = [pscustomobject]@{
                Kind = $Kind; DestinationPrefix = $DestinationPrefix; InterfaceIndex = $InterfaceIndex
                NextHop = $NextHop; RouteMetric = $Metric; PolicyStore = 'ActiveStore'
            }
            throw "Creating $Kind route failed; ownership is unconfirmed. Inspect the route key in State.UncertainRoute. $netErr"
        }
        # Wintun + on-link default: Windows отвечает 1231 «Сетевая папка недоступна»,
        # хотя netsh тот же самый маршрут ставит без вопросов. Пробуем им.
        if ($script:ZSAllowNetshFallback) {
            try {
                $alias = [string](Get-NetAdapter -InterfaceIndex $InterfaceIndex -ErrorAction Stop).Name
                Write-ZSTrace ('netsh: ' + $DestinationPrefix + ' через "' + $alias + '" metric ' + [string]$Metric)
                $null = & netsh interface ipv4 add route ('prefix=' + $DestinationPrefix) ('interface=' + $alias) ('nexthop=' + $NextHop) ('metric=' + [string]$Metric) 'store=active' 2>&1
                $exists = @(Get-ZSWarpIPv4Routes | Where-Object {
                    [string]$_.DestinationPrefix -eq $DestinationPrefix -and
                    [uint32]$_.InterfaceIndex -eq $InterfaceIndex -and [string]$_.NextHop -eq $NextHop
                })
            } catch { Write-ZSTrace ('netsh: ' + $_.Exception.Message) }
        }
        if ($exists.Count -eq 0) {
            $State.UncertainRoute = [pscustomobject]@{
                Kind = $Kind; DestinationPrefix = $DestinationPrefix; InterfaceIndex = $InterfaceIndex
                NextHop = $NextHop; RouteMetric = $Metric; PolicyStore = 'ActiveStore'
            }
            throw "Creating $Kind route failed; ownership is unconfirmed. Inspect the route key in State.UncertainRoute. $netErr"
        }
        # Маршрута не было до вызова и он появился сразу после netsh — значит он наш.
        $created = @($exists[0]); $viaFallback = $true
        Write-ZSTrace ('маршрут создан через netsh: ' + $DestinationPrefix)
    }
    # A successful creation owns this exact key even if its returned object
    # is unexpectedly incomplete; register it before any subsequent checks.
    # Метрику и протокол берём из фактического маршрута: netsh мог поставить своё,
    # а при удалении мы сверяем именно эти поля.
    $recMetric = $Metric; $recProto = 'NetMgmt'
    if ($created.Count -ge 1) {
        if ($null -ne $created[0].PSObject.Properties['RouteMetric']) { $recMetric = [uint16]$created[0].RouteMetric }
        if ($null -ne $created[0].PSObject.Properties['Protocol']) { $recProto = [string]$created[0].Protocol }
    }
    $record = [pscustomobject]@{
        Kind = $Kind; DestinationPrefix = $DestinationPrefix; InterfaceIndex = $InterfaceIndex
        NextHop = $NextHop; RouteMetric = $recMetric; Protocol = $recProto; PolicyStore = 'ActiveStore'
        InstanceId = ''; Status = 'Owned'
    }
    [void]$State.Routes.Add($record)
    if (-not $viaFallback -and ($created.Count -ne 1 -or [string]$created[0].DestinationPrefix -ne $DestinationPrefix -or
        [uint32]$created[0].InterfaceIndex -ne $InterfaceIndex -or [string]$created[0].NextHop -ne $NextHop -or
        [int]$created[0].RouteMetric -ne [int]$Metric -or [string]$created[0].Protocol -ne 'NetMgmt')) {
        throw "The created $Kind route was not returned with the expected identity and properties."
    }
    if ($null -ne $created[0].PSObject.Properties['InstanceID']) {
        $record.InstanceId = [string]$created[0].InstanceID
    }
}

function Assert-ZSWarpPin {
    param([Parameter(Mandatory = $true)]$State)
    $pin = @($State.Routes | Where-Object { $_.Kind -eq 'Endpoint' -and $_.Status -eq 'Owned' })
    if ($pin.Count -ne 1) { throw 'The owned endpoint pin is missing from state.' }
    [void](Get-ZSWarpPhysicalAdapter -InterfaceIndex $pin[0].InterfaceIndex -TunnelName $State.TunnelName)
    $routes = @(Get-ZSWarpIPv4Routes | Where-Object {
        [string]$_.DestinationPrefix -eq $pin[0].DestinationPrefix -and
        [uint32]$_.InterfaceIndex -eq $pin[0].InterfaceIndex -and
        [string]$_.NextHop -eq $pin[0].NextHop -and
        [int]$_.RouteMetric -eq $pin[0].RouteMetric -and [string]$_.Protocol -eq $pin[0].Protocol -and
        (-not $pin[0].InstanceId -or [string]$_.InstanceID -eq $pin[0].InstanceId)
    })
    if ($routes.Count -ne 1) { throw 'The owned endpoint pin is missing or has changed.' }
    $best = Get-ZSWarpBestRoute -Address $State.EndpointIPv4
    if ([string]$best.DestinationPrefix -ne $pin[0].DestinationPrefix -or
        [uint32]$best.InterfaceIndex -ne $pin[0].InterfaceIndex -or
        [string]$best.NextHop -ne $pin[0].NextHop) {
        throw 'Windows did not select the owned physical endpoint /32 route.'
    }
}

function Assert-ZSWarpDefaultWins {
    param([Parameter(Mandatory = $true)]$State, [Parameter(Mandatory = $true)][uint32]$TunnelIndex,
          [switch]$RequireOwned)
    $interfaces = @(Get-NetIPInterface -AddressFamily IPv4 -ErrorAction Stop)
    $tun = @($interfaces | Where-Object { [uint32]$_.InterfaceIndex -eq $TunnelIndex })
    if ($tun.Count -ne 1 -or [string]$tun[0].ConnectionState -ne 'Connected' -or
        [string]$tun[0].InterfaceAlias -ne $State.TunnelName) {
        throw 'The IPv4 tunnel interface is missing, ambiguous, disconnected, or renamed.'
    }
    $effective = [long]$tun[0].InterfaceMetric + 1
    $defaults = @(Get-ZSWarpIPv4Routes | Where-Object { [string]$_.DestinationPrefix -eq '0.0.0.0/0' })
    $ownedCount = 0
    foreach ($route in $defaults) {
        # Skip our exact route on the post-install check, but never skip a foreign one.
        $ours = @($State.Routes | Where-Object {
            $_.Kind -eq 'Default' -and $_.Status -eq 'Owned' -and
            [uint32]$route.InterfaceIndex -eq $_.InterfaceIndex -and [string]$route.NextHop -eq $_.NextHop -and
            [int]$route.RouteMetric -eq $_.RouteMetric -and [string]$route.Protocol -eq $_.Protocol -and
            (-not $_.InstanceId -or [string]$route.InstanceID -eq $_.InstanceId)
        })
        if ($ours.Count -eq 1) { $ownedCount++; continue }
        $iface = @($interfaces | Where-Object { [uint32]$_.InterfaceIndex -eq [uint32]$route.InterfaceIndex })
        if ($iface.Count -ne 1) { throw 'Cannot calculate the effective metric of a competing default route.' }
        $competitor = [long]$iface[0].InterfaceMetric + [long]$route.RouteMetric
        if ($effective -ge $competitor) {
            throw "Tunnel effective metric $effective does not strictly beat competing default metric $competitor. Interface settings were not modified."
        }
    }
    if ($RequireOwned -and $ownedCount -ne 1) { throw 'The owned tunnel default is missing, changed, or ambiguous.' }
    $State.TunnelInterfaceMetric = [long]$tun[0].InterfaceMetric
    $State.TunnelEffectiveMetric = $effective
    Write-ZSTrace ('метрика в порядке: туннель ' + [string]$effective + ', наших default ' + [string]$ownedCount)
}

function Remove-ZSWarpRoutes {
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)]$State)
    if ($State.Type -ne 'ZSWarpRouteState-v1' -or $null -eq $State.Routes) { throw 'Invalid ZSWarp route state.' }
    $errors = New-Object System.Collections.Generic.List[string]
    # Remove defaults first. If one is still present or cannot be identified,
    # retain the endpoint pin so that the tunnel cannot immediately loop.
    $uncertainDefaultPresent = $false
    if ($State.UncertainRoute) {
        try {
            $u = $State.UncertainRoute
            $unknown = @(Get-ZSWarpIPv4Routes | Where-Object {
                [string]$_.DestinationPrefix -eq $u.DestinationPrefix -and
                [uint32]$_.InterfaceIndex -eq $u.InterfaceIndex -and [string]$_.NextHop -eq $u.NextHop
            })
            if ($unknown.Count -gt 0) {
                if ($u.Kind -eq 'Default') { $uncertainDefaultPresent = $true }
                [void]$errors.Add("A $($u.Kind) route of unconfirmed ownership exists; it was not deleted.")
            }
        } catch {
            if ($State.UncertainRoute.Kind -eq 'Default') { $uncertainDefaultPresent = $true }
            [void]$errors.Add('Could not check the route of unconfirmed ownership.')
        }
    }
    foreach ($kind in @('Default', 'Endpoint')) {
        if ($kind -eq 'Endpoint' -and ($uncertainDefaultPresent -or @($State.Routes | Where-Object { $_.Kind -eq 'Default' -and $_.Status -eq 'Owned' }).Count -gt 0)) {
            [void]$errors.Add('Endpoint pin retained because a default could not be safely removed or ruled out.')
            break
        }
        if ($kind -eq 'Endpoint' -and @($State.Routes | Where-Object { $_.Kind -eq 'Endpoint' -and $_.Status -eq 'Owned' }).Count -gt 0) {
            try {
                $indices = @(Get-NetIPInterface -AddressFamily IPv4 -ErrorAction Stop | Where-Object {
                    [string]$_.InterfaceAlias -eq $State.TunnelName
                } | ForEach-Object { [uint32]$_.InterfaceIndex })
                if ($null -ne $State.TunnelInterfaceIndex) { $indices += [uint32]$State.TunnelInterfaceIndex }
                $intercept = @(Get-ZSWarpIPv4Routes | Where-Object {
                    $indices -contains [uint32]$_.InterfaceIndex -and
                    (Test-ZSWarpIPv4PrefixContains -Prefix ([string]$_.DestinationPrefix) -Address $State.EndpointIPv4)
                })
                if ($intercept.Count -gt 0) {
                    [void]$errors.Add('Endpoint pin retained: another tunnel route covers the endpoint; it was not deleted.')
                    break
                }
            } catch {
                [void]$errors.Add('Endpoint pin retained: could not rule out an endpoint-intercepting tunnel route.')
                break
            }
        }
        foreach ($record in @($State.Routes | Where-Object { $_.Kind -eq $kind -and $_.Status -eq 'Owned' })) {
            try {
                $matches = @(Get-ZSWarpIPv4Routes | Where-Object {
                    [string]$_.DestinationPrefix -eq $record.DestinationPrefix -and
                    [uint32]$_.InterfaceIndex -eq $record.InterfaceIndex -and [string]$_.NextHop -eq $record.NextHop
                })
                if ($matches.Count -eq 0) { $record.Status = 'Absent'; continue }
                if ($matches.Count -ne 1 -or [int]$matches[0].RouteMetric -ne $record.RouteMetric -or
                    [string]$matches[0].Protocol -ne $record.Protocol -or
                    ($record.InstanceId -and [string]$matches[0].InstanceID -ne $record.InstanceId)) {
                    throw "Route $($record.DestinationPrefix) has changed or is ambiguous; refusing to delete it."
                }
                Remove-NetRoute -InputObject $matches[0] -Confirm:$false -ErrorAction Stop
                $remaining = @(Get-ZSWarpIPv4Routes | Where-Object {
                    [string]$_.DestinationPrefix -eq $record.DestinationPrefix -and
                    [uint32]$_.InterfaceIndex -eq $record.InterfaceIndex -and [string]$_.NextHop -eq $record.NextHop
                })
                if ($remaining.Count -ne 0) { throw "Removal of $($record.DestinationPrefix) could not be verified." }
                $record.Status = 'Removed'
            } catch { [void]$errors.Add($_.Exception.Message) }
        }
    }
    if ($errors.Count -gt 0) {
        $State.Phase = 'CleanupPending'
        $ex = New-Object System.InvalidOperationException ('Route cleanup incomplete: ' + ($errors -join '; '))
        $ex.Data['ZSWarpState'] = $State
        throw $ex
    }
    $State.Phase = 'Removed'
}

function Throw-ZSWarpWithRollback {
    param([Parameter(Mandatory = $true)]$State, [Parameter(Mandatory = $true)][string]$Message)
    $cleanup = $null
    try { Remove-ZSWarpRoutes -State $State } catch { $cleanup = $_.Exception.Message }
    $text = $Message
    if ($cleanup) { $text += ' Rollback incomplete: ' + $cleanup }
    if ($State.UncertainRoute) { $text += ' A failed creation had unconfirmed ownership; inspect State.UncertainRoute.' }
    $ex = New-Object System.InvalidOperationException $text
    $ex.Data['ZSWarpState'] = $State
    throw $ex
}

function Initialize-ZSWarpRoutes {
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][string]$ConfigPath,
          [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][string]$TunnelName)
    $state = [pscustomobject]@{
        Type = 'ZSWarpRouteState-v1'; Phase = 'Initializing'; TunnelName = $TunnelName
        EndpointIPv4 = $null; TunnelInterfaceIndex = $null; TunnelInterfaceMetric = $null
        TunnelEffectiveMetric = $null; IPv6Mode = 'Unchanged'; UncertainRoute = $null
        Routes = (New-Object System.Collections.ArrayList)
    }
    try {
        try { $config = Get-Content -LiteralPath $ConfigPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop }
        catch { throw 'Cannot read or parse the usque JSON configuration.' }
        $endpoint = [string]$config.endpoint_v4
        $config = $null
        $address = $null
        if ($endpoint -notmatch '^(\d{1,3}\.){3}\d{1,3}$' -or
            -not [System.Net.IPAddress]::TryParse($endpoint, [ref]$address) -or
            $address.AddressFamily -ne [System.Net.Sockets.AddressFamily]::InterNetwork -or
            $address.ToString() -ne $endpoint) { throw 'endpoint_v4 must be a canonical IPv4 address without a port.' }
        $bytes = $address.GetAddressBytes()
        if ($bytes[0] -eq 0 -or $bytes[0] -eq 127 -or $bytes[0] -ge 224 -or
            ($bytes[0] -eq 169 -and $bytes[1] -eq 254)) { throw 'endpoint_v4 is not a usable unicast remote IPv4 address.' }
        $state.EndpointIPv4 = $endpoint
        $best = Get-ZSWarpBestRoute -Address $endpoint
        [void](Get-ZSWarpPhysicalAdapter -InterfaceIndex ([uint32]$best.InterfaceIndex) -TunnelName $TunnelName)
        Add-ZSWarpOwnedRoute -State $state -Kind Endpoint -DestinationPrefix ($endpoint + '/32') `
            -InterfaceIndex ([uint32]$best.InterfaceIndex) -NextHop ([string]$best.NextHop) -Metric 1
        Assert-ZSWarpPin -State $state
        $state.Phase = 'Initialized'
        return $state
    } catch { Throw-ZSWarpWithRollback -State $state -Message ('Route initialization failed: ' + $_.Exception.Message) }
}

function Add-ZSWarpTunnelRoutes {
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)]$State)
    if ($State.Type -ne 'ZSWarpRouteState-v1' -or $State.Phase -ne 'Initialized') {
        throw 'Add-ZSWarpTunnelRoutes requires an original Initialized state; do not call it twice.'
    }
    try {
        Write-ZSTrace 'маршруты: проверяю пин эндпоинта'
        Assert-ZSWarpPin -State $State
        Write-ZSTrace 'маршруты: ищу подключённый интерфейс туннеля'
        $interfaces = @(Get-NetIPInterface -AddressFamily IPv4 -ErrorAction Stop | Where-Object {
            [string]$_.InterfaceAlias -eq $State.TunnelName -and [string]$_.ConnectionState -eq 'Connected'
        })
        if ($interfaces.Count -ne 1) { throw 'Expected one connected IPv4 tunnel interface with the exact requested alias.' }
        $index = [uint32]$interfaces[0].InterfaceIndex
        $endpointPin = @($State.Routes | Where-Object { $_.Kind -eq 'Endpoint' -and $_.Status -eq 'Owned' })[0]
        if ($index -eq [uint32]$endpointPin.InterfaceIndex) { throw 'Tunnel and physical endpoint interfaces must be different.' }
        $State.TunnelInterfaceIndex = $index
        Write-ZSTrace ('маршруты: туннель index=' + [string]$index + ', проверяю метрику')
        Assert-ZSWarpDefaultWins -State $State -TunnelIndex $index
        Write-ZSTrace 'маршруты: ставлю default в туннель'
        Add-ZSWarpOwnedRoute -State $State -Kind Default -DestinationPrefix '0.0.0.0/0' `
            -InterfaceIndex $index -NextHop '0.0.0.0' -Metric 1
        Write-ZSTrace 'маршруты: default поставлен, перепроверяю пин'
        Assert-ZSWarpPin -State $State
        Write-ZSTrace 'маршруты: проверяю, что default победил'
        Assert-ZSWarpDefaultWins -State $State -TunnelIndex $index -RequireOwned
        # More-specific routes may intentionally override a default. Require at
        # least one representative public destination to choose our default.
        # Find-NetRoute на on-link default через Wintun отдаёт 1231 «Сетевая папка
        # недоступна» — это не отказ маршрута, а ограничение самой функции. Такие
        # пробы не считаем провалом: настоящую проверку делает запрос trace.
        $verified = $false; $probeErrors = 0; $probeMissed = 0
        foreach ($probe in @('1.1.1.1', '8.8.8.8', '9.9.9.9', '128.0.0.1', '223.1.1.1')) {
            if ($probe -eq $State.EndpointIPv4) { continue }
            $route = $null; $how = 'Find-NetRoute'
            try { $route = Get-ZSWarpBestRoute -Address $probe }
            catch {
                $route = Get-ZSWarpRouteByTable -Address $probe
                $how = 'по таблице'
            }
            if (-not $route) { $probeErrors++; Write-ZSTrace ('проба ' + $probe + ': маршрут не найден'); continue }
            if ([string]$route.DestinationPrefix -eq '0.0.0.0/0' -and
                [uint32]$route.InterfaceIndex -eq $index -and [string]$route.NextHop -eq '0.0.0.0') {
                $verified = $true; break
            }
            $probeMissed++
            Write-ZSTrace ('проба ' + $probe + ' (' + $how + '): выбрала ' + [string]$route.DestinationPrefix + ' if' + [string]$route.InterfaceIndex)
        }
        if (-not $verified -and $probeMissed -gt 0) {
            throw 'No representative destination selected the new tunnel default; more-specific routes or policy may override it.'
        }
        if (-not $verified) { Write-ZSTrace 'пробы Find-NetRoute недоступны — решает проверка trace' }
        $State.Phase = 'Active'
        return $State
    } catch { Throw-ZSWarpWithRollback -State $State -Message ('Adding tunnel route failed: ' + $_.Exception.Message) }
}
